import java.util.Scanner;
class Program4
{

	public static void check(String str)
	{
		int firstIndex = 0;
		int lastIndex = str.length() - 1;

		int middleIndex = firstIndex + (lastIndex - firstIndex)/2;

		char middleChar = str.charAt(middleIndex);

		if(middleChar == 'a' || middleChar == 'e' || middleChar == 'i' ||
			middleChar == 'o' || middleChar == 'u')
		{
			System.out.println("Vowel : "+middleChar);
		}
		else
		{
			System.out.println("Consonant : "+middleChar);
		}

	}

	public static void main(String[] args)
	{
		System.out.println("main method starts.......");

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the String value : ");
		String str = sc.nextLine();

		check(str);

		System.out.println("main method ends........");
	}
}