import java.util.Scanner;
class Program3
{

	public static void toLowerCase(String str)
	{
		char []ch = str.toCharArray();	// JAVA

		for(int index = 0; index <= ch.length - 1; index++ )
		{
			ch[index] = (char) (ch[index] + 32);
		}

		for(int index = 0; index <= ch.length -1; index++)
		{	
			System.out.print(ch[index]);
		}

	}

	public static void main(String[] args)
	{
		System.out.println("main method starts.......");

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the String value : ");

		String str = sc.nextLine();

		toLowerCase(str);

		System.out.println();

		System.out.println("main method ends........");
	}
}