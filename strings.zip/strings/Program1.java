class Program1
{
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		String str = "javaiseasy";

		char ch[] = str.toCharArray(); // returns char array

		for(int index = 6; index <= 9; index++ )
		{
			System.out.print(ch[index]);
		}

		System.out.println();
		System.out.println("main method ends.....");
	}
}