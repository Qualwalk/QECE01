class Student
{
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		int id = 101;
		//String name = "Dinga"; approach -1
		String name = new String("Dinga"); //approach-2

		int chars = name.length(); //syntax variable_name.length()
		char ch = name.charAt(4); //syntax variable_name.charAt(Index)

		System.out.println("Id : "+id);
		System.out.println("Name : "+name);
		System.out.println("Number of chars : "+chars);
		System.out.println("ch : "+ch);

		System.out.println("main method ends.....");
	}
}