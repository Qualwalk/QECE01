import java.util.Scanner;
class Program2
{
	public static void main(String[] args)
	{
		System.out.println("main method starts.......");

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the String value : ");

		String str = sc.nextLine();

		int res = str.length();

		System.out.println("Length of the given String : "+res);

		System.out.println("main method ends........");
	}
}