class Program1
{
	public static void main(String[] args)
	{
		System.out.println("main method starts....");

		for(int a = 1; a <= 5; a++)
		{
			System.out.println("a = "+a);
		}


		System.out.println("main method ends....");
	}
}