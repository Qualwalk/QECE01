class Program2
{	
	public static void main(String[] args)
	{
		System.out.println("main method starts....");


		for(int a = 1; a <= 5; a++)
		{
			for(int b = 1; b <= 5; b++)
			{
				System.out.print(" "+a);
			}
				System.out.println();
		}


		System.out.println("main method ends......");
	}
}