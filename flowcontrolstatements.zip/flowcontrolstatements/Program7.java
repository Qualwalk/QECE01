class Program7
{
	public static void main(String[] args)
	{
		System.out.println("main method starts......");

		for(int index = 1; index <= 5; index++)
		{
			if(index == 4)
			{
				break;
			}
			System.out.println("index : "+index);
		}

		System.out.println("main method ends......");
	}
}