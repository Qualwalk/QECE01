import java.util.Scanner;
class Program8
{
	public static void main(String[] args)
	{
		System.out.println("main method starts......");

		int sum;
		int n;

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the n value :");
		n = sc.nextInt();

		sum = 0;


		for(int a = 1; a <= n; a++)
		{
			sum = sum + a;
		}
		System.out.println("Sum = "+sum);

		System.out.println("main method ends........");
	}
}