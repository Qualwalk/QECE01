import java.util.Scanner;

class FindGreatest
{
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		int num1;
		int num2;

		Scanner sc = new Scanner(System.in); 
		
		System.out.println("enter number 1 :");
		num1 = sc.nextInt();

		System.out.println("enter number 2 : ");
		num2 = sc.nextInt();
		
		if(num1 > num2)
		{
			System.out.println("num1 is greatest....");
		}
		else
		{
			System.out.println("num2 is greatest....");
		}


		System.out.println("main method ends......");
	}
}