class Program6
{	
	public static void main(String[] args)
	{
		System.out.println("main method starts....");

		int counter;
		counter = 5;

		do
		{

			System.out.println("Java class");
			counter++;

		}while(counter <= 3);

		System.out.println("main method ends....");
	}
}