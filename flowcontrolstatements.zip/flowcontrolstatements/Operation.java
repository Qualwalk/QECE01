import java.util.Scanner;

class Operation
{
	public static void main(String[] args)
	{

		System.out.println("main method starts......");


		int number;

		Scanner sc = new Scanner(System.in);// Keyboard input

		System.out.println("enter the number : ");
		number = sc.nextInt();

		if(number % 2 == 0)// boolean condition true/false
		{
			System.out.println("Number is completely divisible by 2");
		}


		System.out.println("main method ends........");
	}
}