class Message
{
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		String tickmark = "double";

		switch(tickmark)
		{
			case "single" : System.out.println("message sent");
							break;

			case "double" : System.out.println("message sent and received");
							break;

			case "blue"   : System.out.println("message sent, received and read");
							break;

			default 	  : System.out.println("message not sent");
							break;

		}


		System.out.println("main method ends.....");
	}
}