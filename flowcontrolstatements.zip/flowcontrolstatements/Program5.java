class Program5
{	
	public static void main(String[] args)
	{
		System.out.println("main method starts....");

		int counter;
		counter = 1;

		while(counter <= 5)
		{
			System.out.println("Java class");
			++counter;
		}

		System.out.println("main method ends....");
	}
}