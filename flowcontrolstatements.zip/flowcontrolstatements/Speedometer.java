import java.util.Scanner;
class Speedometer
{
	public static void main(String[] args)
	{
		System.out.println("main method starts......");


		int speed;
		String speedlight;

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the speed : ");

		speed = sc.nextInt();
		

		if(speed > 0 && speed <= 40)
		{
			speedlight = "blue";
			System.out.println("drive mode : speedlight "+speedlight);
		}
		else if(speed>40 && speed <= 80)
		{
			speedlight = "orange";
			System.out.println("economy mode : speedlight "+speedlight);
		}
		else if(speed>80 && speed <=120)
		{
			speedlight = "red";
			System.out.println("power mode : speedlight "+speedlight);
		}
		else
		{
			speedlight = "yellow";
			System.out.println("neutral : speedlight "+speedlight);
		}



		System.out.println("main method ends......");
	}
}