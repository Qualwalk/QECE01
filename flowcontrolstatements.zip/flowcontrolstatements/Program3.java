class Program3
{
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		for(int a = 1; a <= 4; a++)
		{
			for(int b = 1; b <= a; b++)
			{
				System.out.print(" * ");
			}
			System.out.println();
		}

		System.out.println("main method ends.....");
	}
}