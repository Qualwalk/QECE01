class Sample
{

	public static int test(int num1)
	{
		System.out.println("test method starts......");

		

		System.out.println("test methods ends......");

		return num;
		
	}

	public static void main(String[] args)
	{
		System.out.println("main method starts.....");
		int a;
		int b;

		a = 10;

		b = test(a);

		System.out.println(" b : "+b);

		System.out.println("main method ends......");
	}
}
//method