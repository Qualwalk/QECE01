class Square
{

	public static void area(double length)
	{
		System.out.println("area method starts......");

		double areaOfSquare;

		areaOfSquare = length * length;
		System.out.println("area of square : "+areaOfSquare);

		System.out.println("area method ends......");
	}

	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		double length;

		length = 10.0;		
		
		area(length);

		System.out.println("main method ends.......");
	}
}