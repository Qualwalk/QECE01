class Circle
{
	public static void area(double radius)
	{
		double areaOfCircle;
		areaOfCircle = 3.14 * radius * radius;
		System.out.println("area : "+ areaOfCircle);
	}

	public static void main(String[] args)
	{
		System.out.println("main method starts......");

		double radius1;
		double radius2;
		double radius3;

		radius1 = 2.0;
		radius2 = 4.0;
		radius3 = 6.0;

		area(radius1);
		area(radius2);
		area(radius3);

		System.out.println("main method ends........");
	}
}