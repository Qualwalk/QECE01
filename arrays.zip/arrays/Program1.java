class Program1
{

	public static void display(int array[])
	{
		System.out.println("display method starts......");

		int size;

		size = array.length;

		for(int index = 0;index <= size-1; index++)
		{
			System.out.println("array ["+index+"] : "+array[index]);
		}

		System.out.println("display method ends.......");
	}
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		int array[];

		array = new int[7];

		array[0] = 10;
		array[1] = 12;
		array[2] = 14;
		array[3] = 16;
		array[4] = 18;
		array[5] = 20;
		array[6] = 22;

		System.out.println("length of the array : "+array.length);

		display(array);

		System.out.println("main method ends.....");
	}
}