import java.util.Scanner;
class Program5
{

	public static void highest(int a[])
	{
		System.out.println("highest method starts......");

		int max;

		max = a[0];

		for(int index=1; index <= a.length-1; index++)
		{
			if(a[index] > max)
			{
				max = a[index];
			}
		}
		
		System.out.println("Maximum Element is : "+max);

		System.out.println("highest method ends.......");
	}

	public static void least(int a[])
	{
		System.out.println("least method starts......");

		int min;

		min = a[0];

		for(int index = 1;index <= a.length-1; index++)
		{
			if(a[index] < min)
			{
				min = a[index];
			}
		}

		System.out.println("Least element is : "+min);
		System.out.println("least method ends......");
	}

	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		int a[];
		int size;

		a = new int[8];

		size = a.length;

		Scanner sc = new Scanner(System.in);

		for(int index = 0; index <= size-1; index++)
		{
			System.out.println("enter the array element : ");
			a[index] = sc.nextInt();
		}

		highest(a);
		least(a);

		System.out.println("main method ends.....");
	}
}