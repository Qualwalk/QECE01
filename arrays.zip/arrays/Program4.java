import java.util.Scanner;
class Program4
{

	public static void print(int a[])
	{
		System.out.println("print method starts......");

		//first index, middle index, last index
		int firstIndex;
		int middleIndex;
		int lastIndex;

		firstIndex = 0;
		lastIndex = a.length - 1; // 6
		middleIndex = firstIndex + (lastIndex - firstIndex)/2; // 3
		

		System.out.println("First Element : "+a[firstIndex]);
		System.out.println("Middle Element : "+a[middleIndex]);
		System.out.println("Last Element : "+a[lastIndex]);

		
		System.out.println("print method ends.......");
	}
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		int a[];
		int size;

		a = new int[8];

		size = a.length;

		Scanner sc = new Scanner(System.in);

		for(int index = 0; index <= size-1; index++)
		{
			System.out.println("enter the array element : ");
			a[index] = sc.nextInt();
		}

		print(a);

		System.out.println("main method ends.....");
	}
}