import java.util.Scanner;
class Program3
{

	public static void sumOfArray(int a[])
	{
		System.out.println("sumOfArray method starts......");

		int sum;
		int size;

		size = a.length;

		sum = 0;

		for(int index = 0; index <= size-1; index++)
		{
			sum = sum + a[index];
		}

		System.out.println("Sum : "+sum);
		
		System.out.println("sumOfArray method ends.......");
	}
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		int a[];
		int size;

		a = new int[5];

		size = a.length;

		Scanner sc = new Scanner(System.in);

		for(int index = 0; index <= size-1; index++)
		{
			System.out.println("enter the array element : ");
			a[index] = sc.nextInt();
		}

		sumOfArray(a);

		System.out.println("main method ends.....");
	}
}