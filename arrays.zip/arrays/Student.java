class Student
{
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		int id;

		String name;

		//data_type array_name[]  || data_type []array_name

		double []marks;

		//array_name = new data_type[size]

		marks = new double[5];		

		id = 101;

		name = "Dinga";

		// array_name[index] note: index--> 0 and index ---> size-1
		marks[0] = 60.2;
		marks[1] = 70.1;
		marks[2] = 55.5;
		marks[3] = 80.4;
		marks[4] = 80.0;

		System.out.println("Id : "+id);

		System.out.println("name : "+name);

		// array_name[index]---> value
		System.out.println("mark_invo : "+marks[0]);
		System.out.println("mark_s : "+marks[1]);
		System.out.println("mark_itc : "+marks[2]);
		System.out.println("mark_opt : "+marks[3]);
		System.out.println("mark_oops : "+marks[4]);

		System.out.println("main method ends......");
	}
	
}