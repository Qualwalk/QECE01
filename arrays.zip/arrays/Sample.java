class Sample
{
	public static void main(String[] args)
	{
		System.out.println("main method starts......");

		//Declaration and creation of array in single step
		//data_type array_name[] = new data_type[size];


		int a[] = new int[3];

		a[0] = 10;


		System.out.println("a[0] : "+a[0]);//value
		System.out.println("a[1] : "+a[1]);//default value integer is 0  
		System.out.println("a[2] : "+a[2]);//default value integer is 0 

		System.out.println("main method ends......");
	}
}
//1. size of the array can be byte,short and integer
//2. Index must always size-1 otherwise it leads to ArrayIndexOutOfBoundsException
//3. If array is not initalised then default value will be present