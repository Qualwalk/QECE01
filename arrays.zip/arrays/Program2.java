import java.util.Scanner;
class Program2
{

	public static void display(int array[])
	{
		System.out.println("display method starts......");

		int size;

		size = array.length;

		for(int index = 0;index <= size-1; index++)
		{
			System.out.println("array ["+index+"] : "+array[index]);
		}

		System.out.println("display method ends.......");
	}
	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		int array[];
		int size;

		array = new int[7];

		size = array.length;

		Scanner sc = new Scanner(System.in);

		for(int index = 0; index <= size-1; index++ )
		{
			System.out.println("enter the array element : ");
			array[index] = sc.nextInt();
		}
		
		System.out.println("length of the array : "+array.length);

		display(array);

		System.out.println("main method ends.....");
	}
}