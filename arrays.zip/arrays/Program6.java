class Program6
{
	public static void display(char ch[])
	{
		System.out.println("print method starts......");

		for(int index = 0; index <= ch.length-1; index++)
		{
			System.out.print(ch[index]);
		}
		System.out.println();
		System.out.println("print method ends......");
	}

	public static void main(String[] args)
	{
		System.out.println("main method starts.....");

		char ch[] = {'j','a','v','a',' ','i','s',' ','e','a','s','y'};
		
		display(ch);

		System.out.println("main method ends.....");
	}
}